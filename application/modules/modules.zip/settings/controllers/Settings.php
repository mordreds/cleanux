<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends MX_Controller 
{
  /********** Constructor ************/
  public function __construct() {
    parent::__construct();
  }
  /********** Constructor ************/

  /********** Index call  ************/
  public function index() {
    redirect("dashboard");
  }
  /********** Index call  ************/

  /****** company Interface  *********/
  public function company() {
    # Permission Check
     if(!isset($_SESSION['user']['username']) && !isset($_SESSION['user']['roles']))
      redirect('dashboard');
    else
    {
      /****** Required Parameters To Render A Page ******/
      $this->load->model('access/model_access');
      $this->load->model('globals/model_retrieval');
      $data['_Permission_DB'] = self::$_Permission_DB;
      $data['page_controller'] = $this->uri->segment(1);
      $data['controller_function'] = $this->uri->segment(2); 
      /****** Required Parameters To Render A Page ******/
      /****** Additional Functions  ****************/
      $dbres = self::$_Default_DB;
      $tablename = "hr_company_info";
      $return_dataType="php_object";
      $condition = array('id' => 1);

      $company_info = $this->model_retrieval->retrieve_allinfo($dbres,$tablename,$return_dataType,$condition);

      if(isset($company_info['ERR']['message'])) {
        $data['company_info'] = "";
        $this->session->set_flashdata('error',"Uable To Retrieve Company Details");
      }
      else
        $data['company_info'] = $company_info;

      /****** Additional Functions  ****************/
      /***************** Interface *****************/
      $data['title'] = "Company Details"; 
      $this->load->view('header',$data); 
      $this->load->view('company',$data); 
      $this->load->view('footer'); 
      /***************** Interface *****************/
    }
  }
  /****** company Interface  *********/
  /****** Save Company Details  ******/
  public function save_company_details() {
    if(in_array('users', $_SESSION['user']['roles'])) {
      $this->form_validation->set_rules('id','ID','trim|required');
      $this->form_validation->set_rules('name','Name','trim|required');
      $this->form_validation->set_rules('postal_addr','Postal Address','trim|required');
      $this->form_validation->set_rules('residence_addr','Residence Address','trim|required');
      $this->form_validation->set_rules('phone_num_1','Primary Telephone','trim|required');
      $this->form_validation->set_rules('phone_num_2','Secondary Telephone','trim|required');
      $this->form_validation->set_rules('fax','Fax','trim');
      $this->form_validation->set_rules('email','Email','trim|required');
      $this->form_validation->set_rules('website','Website','trim');
      $this->form_validation->set_rules('mission','Mission Statment','trim');
      $this->form_validation->set_rules('vision','vision Statment','trim');
      $this->form_validation->set_rules('tin_number','Tin Number','trim');
      if ($this->form_validation->run() === FALSE) {
        $this->session->set_flashdata('error',"Validation Error");
        redirect('settings/company');
      }
      else {
        $this->load->model('globals/model_insertion');
        $this->load->model('globals/model_update');

        $id = $this->input->post('id');
        $dbres = self::$_Default_DB;
        $tablename = "hr_company_info";
        $data = [
          'name' => $this->input->post('name'),
          'postal_address' => $this->input->post('postal_addr'),
          'residence_address' => $this->input->post('residence_addr'),
          'telephone_1' => $this->input->post('phone_num_1'),
          'telephone_2' => $this->input->post('phone_num_2'),
          'fax' => $this->input->post('fax'),
          'email' => $this->input->post('email'),
          'website' => $this->input->post('website'),
          'mission' => $this->input->post('mission'),
          'vision' => $this->input->post('vision'),
          'tin_number' => $this->input->post('tin_number')
        ];
        $return_dataType="php_object";

        if(empty($id)) {
          $query_result = $this->model_insertion->datainsert($dbres,$tablename,$data);
          if($query_result)
            $this->session->set_flashdata('success',"Company Registration Successful");
          else
            $this->session->set_flashdata('error',"Company Registration Failed");
        }
        else {
          $where_condition = ['id' => $this->input->post('id')];

          $query_result = $this->model_update->update_info($dbres,$tablename,$return_dataType,$data,$where_condition) ;
          if($query_result)
            $this->session->set_flashdata('success',"Company Details Updated");
          else
            $this->session->set_flashdata('error',"Update Failed");
        }

        redirect('settings/company');
      }
    }
    else 
      $this->session->set_flashdata('error','Permission Denied.Contact Administrator');
      redirect('settings/company');
  }
  /****** Save Company Details  ******/
  
}//End of Class
